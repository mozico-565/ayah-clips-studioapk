# طريقة الحصول على APK
1. ارفع محتويات المجلد إلى مستودع GitHub الحالي، وليس ZIP فقط.
2. افتح Actions > Build Ayah Clips APK > Run workflow.
3. بعد نجاح البناء افتح Artifacts > Ayah-Clips-debug-APK، ثم فك الضغط لتجد app-debug.apk.

هذه محاولة تغليف Android Debug، وليست APK جاهزًا مختبرًا. لم يُتحقق من تشغيل Whisper أو FFmpeg داخل Android WebView، ولا من نجاح بناء GitHub Actions. يتطلب تنزيل نموذج التعرف واتصال API الإنترنت.
