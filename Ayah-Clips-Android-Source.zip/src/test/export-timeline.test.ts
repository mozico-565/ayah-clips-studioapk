import { describe, expect, it } from "vitest";
import { buildCaptionSegments } from "../lib/export-timeline";
import type { Clip } from "../lib/alignment";

const verses = [
  { surah: 1, n: 1, text: "بسم الله الرحمن الرحيم" },
  { surah: 1, n: 2, text: "الحمد لله رب العالمين" },
];
const clip: Clip = { id: "test", from: 0, to: 1, start: 0, end: 5 };
describe("MP4 caption timeline", () => {
  it("preserves small silence gaps and the exact clip duration", () => {
    const segments = buildCaptionSegments(
      clip,
      [
        { start: 0.01, end: 2 },
        { start: 2.04, end: 4.99 },
      ],
      verses,
      "الفاتحة",
    );
    expect(segments.filter((s) => !s.text).map((s) => s.dur)).toEqual([0.01, 2.04 - 2, 5 - 4.99]);
    expect(segments.reduce((sum, s) => sum + s.dur, 0)).toBeCloseTo(5, 10);
  });
  it("clips captions to the selected audio boundaries", () => {
    const segments = buildCaptionSegments(
      { ...clip, start: 1, end: 4 },
      [
        { start: 0, end: 2 },
        { start: 2, end: 5 },
      ],
      verses,
      "الفاتحة",
    );
    expect(segments.map((s) => s.dur)).toEqual([1, 2]);
  });
  it("rejects NaN/reversed clip limits and overlapping/unresolved verses", () => {
    expect(() => buildCaptionSegments({ ...clip, end: NaN }, [], [], "")).toThrow();
    expect(() => buildCaptionSegments({ ...clip, end: 0 }, [], [], "")).toThrow();
    expect(() =>
      buildCaptionSegments(
        clip,
        [
          { start: 0, end: 3 },
          { start: 2, end: 5 },
        ],
        verses,
        "",
      ),
    ).toThrow();
    expect(() => buildCaptionSegments(clip, [{ start: 0, end: 0 }], [verses[0]], "")).toThrow();
  });
  it("rejects captions without matching Quran text or without a verse in the clip", () => {
    expect(() => buildCaptionSegments(clip, [{ start: 0, end: 5 }], [], "")).toThrow();
    expect(() =>
      buildCaptionSegments({ ...clip, start: 6, end: 8 }, [{ start: 0, end: 5 }], [verses[0]], ""),
    ).toThrow();
  });
});
