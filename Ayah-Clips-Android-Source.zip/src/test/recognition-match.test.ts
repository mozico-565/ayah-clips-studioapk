import { describe, expect, it } from "vitest";
import {
  matchRecognizedWords,
  normalizeArabic,
  type RecognizedWord,
} from "../lib/recognition-match";
import type { Verse } from "../lib/quran";

const verse: Verse = { surah: 1, n: 1, text: "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ" };
const words: RecognizedWord[] = [
  { text: "بسم", timestamp: [1, 1.5] },
  { text: "الله", timestamp: [1.6, 2] },
  { text: "الرحمن", timestamp: [2.4, 3] },
  { text: "الرحيم", timestamp: [3.2, 4] },
];

describe("ASR timestamp matching (unit data, not an acoustic benchmark)", () => {
  it("normalizes the canonical diacritics without changing word order", () => {
    expect(normalizeArabic(verse.text)).toBe("بسم الله الرحمن الرحيم");
  });
  it("uses the observed start and end instead of text-length timing", () => {
    expect(matchRecognizedWords([verse], words, 12)[0].timing).toEqual({ start: 1, end: 4 });
  });
  it("rejects a missing final word rather than shortening the verse", () => {
    expect(matchRecognizedWords([verse], words.slice(0, 3), 12)[0].timing).toBeNull();
  });
  it("rejects a missing first word", () => {
    expect(matchRecognizedWords([verse], words.slice(1), 12)[0].timing).toBeNull();
  });
  it("rejects missing or invalid final timestamps", () => {
    for (const end of [null, NaN, Infinity, 30]) {
      const invalid = words.map((word, i): RecognizedWord =>
        i === 3 ? { ...word, timestamp: [3.2, end] } : word,
      );
      expect(matchRecognizedWords([verse], invalid, 12)[0].timing).toBeNull();
    }
  });
  it("returns no guessed timings for silence/unrelated recognition", () => {
    expect(matchRecognizedWords([verse], [], 12)[0].timing).toBeNull();
    expect(
      matchRecognizedWords([verse], [{ text: "كلام مختلف تماما", timestamp: [0, 3] }], 12)[0]
        .timing,
    ).toBeNull();
  });
});
