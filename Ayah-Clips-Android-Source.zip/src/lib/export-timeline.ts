import type { Clip, Timing } from "./alignment";
import type { Verse } from "./quran";

export type CaptionSegment = { text: string; caption: string; number?: number; dur: number };

export function buildCaptionSegments(
  clip: Clip,
  timings: Timing[],
  verses: Verse[],
  caption: string,
): CaptionSegment[] {
  if (
    !Number.isFinite(clip.start) ||
    !Number.isFinite(clip.end) ||
    clip.start < 0 ||
    clip.end <= clip.start
  )
    throw new Error("حدود المقطع غير صالحة");
  if (
    timings.length !== verses.length ||
    timings.some(
      (timing, i) =>
        !Number.isFinite(timing.start) ||
        !Number.isFinite(timing.end) ||
        timing.start < 0 ||
        timing.end <= timing.start ||
        (i > 0 && timing.start < timings[i - 1].end),
    )
  )
    throw new Error("راجع توقيت الآيات قبل التصدير");
  const segments: CaptionSegment[] = [];
  let cursor = clip.start;
  for (let i = 0; i < timings.length; i++) {
    const start = Math.max(timings[i].start, clip.start);
    const end = Math.min(timings[i].end, clip.end);
    if (end <= start) continue;
    if (start > cursor) segments.push({ text: "", caption, dur: start - cursor });
    segments.push({ text: verses[i].text, caption, number: verses[i].n, dur: end - start });
    cursor = end;
  }
  if (!segments.some((segment) => segment.text)) throw new Error("لا توجد آيات داخل المقطع");
  if (cursor < clip.end) segments.push({ text: "", caption, dur: clip.end - cursor });
  return segments;
}
