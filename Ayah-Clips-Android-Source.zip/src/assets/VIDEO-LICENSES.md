# Background footage

- Snowy mountains landscape (Mixkit clip 2602): https://mixkit.co/free-stock-video/snowy-mountains-landscape-2602/
- Snowy trees on a mountain (Mixkit clip 2604): https://mixkit.co/free-stock-video/snowy-trees-on-a-mountain-2604/
- Mixkit Stock Video Free License: https://mixkit.co/license/#videoFree — downloaded preview footage used as silent looping backgrounds.
- Makkah Al-Mukarramah -Kaaba- Ramadan 2016, World of Travel: https://commons.wikimedia.org/wiki/File:Makkah_Al-Mukarramah_-Kaaba-_Ramadan_2016.webm — CC BY 3.0 https://creativecommons.org/licenses/by/3.0/ . Kaaba background is a silent resized 10-second excerpt starting at 15s; Mosque background is a different silent resized excerpt starting at 55s. Both depict the Grand Mosque, not a separate mosque interior. Include attribution when distributing exports using these backgrounds. ZIP exports include credits.txt; native sharing includes the credit as accompanying text when supported. A standalone downloaded MP4 does not embed attribution: copy the visible source credit when publishing it.

# Quran typography
Amiri and Amiri Quran by Khaled Hosny and contributors, SIL Open Font License 1.1. Source https://github.com/aliftype/amiri ; full license in AMIRI-LICENSE.txt.

The original ten binary assets were recovered unchanged during the audit and are included under public/assets. Asset manifests retain their original Lovable URLs for provenance while using portable local URLs at runtime.

# ASR
Xenova/whisper-base, ONNX conversion of OpenAI Whisper multilingual base, Apache-2.0 model repository. Downloads model weights only; inference is local. Quran text is obtained from the quran-uthmani edition of AlQuran Cloud / Tanzil; no recognized transcript replaces the canonical Quran text.
