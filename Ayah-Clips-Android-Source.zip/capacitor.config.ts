import type {CapacitorConfig} from "@capacitor/cli";
const config:CapacitorConfig={appId:"com.mozico.ayahclips",appName:"Ayah Clips",webDir:"dist-mobile"};
export default config;
